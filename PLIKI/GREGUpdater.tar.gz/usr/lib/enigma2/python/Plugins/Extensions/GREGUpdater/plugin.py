# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/GREGUpdater/plugin.py
from Screens.Screen import Screen
from Screens.Console import Console
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap, NumberActionMap
from Components.MenuList import MenuList
from Components.Sources.List import List
from Plugins.Plugin import PluginDescriptor
from Components.Button import Button
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from enigma import eConsoleAppContainer
import Components.PluginComponent
from Tools.Directories import pathExists, fileExists
import glob
import os
path = '/usr/lib/enigma2/python/Plugins/Extensions/GREGUpdater/scripts/'

class GREGUpdater(Screen):
    skin = '\n\t<screen backgroundColor="black" flags="wfNoBorder" name="GREGUpdater" position="center,center" size="973,857" title="GREGUpdater" borderWidth="0" borderColor="black">\n\t\t<eLabel backgroundColor="black" font="Regular; 24" foregroundColor="unffffff" halign="center" position="43,634" size="900,54" text="WAZNE_ZROBIC_KOPIE_BOXA" transparent="1" valign="bottom" zPosition="4" />\n\t\t<eLabel backgroundColor="black" font="Regular; 24" foregroundColor="unffffff" halign="center" position="41,694" size="900,63" text="NAJLEPIEJ_INSTALACJA_NA_CZYSTO_SZCZEGOLNIIE_PRZY_INSTALACJI_FULL" transparent="1" valign="bottom" zPosition="4" />\n\t\t<ePixmap pixmap="skin_default/buttons/red.png" position="39,801" size="140,40" alphatest="on" />\n\t\t<ePixmap pixmap="skin_default/buttons/green.png" position="772,798" size="132,40" alphatest="on" />\n\t\t<widget name="key_red" position="46,802" zPosition="1" size="134,40" font="Regular;20" halign="center" valign="center" backgroundColor="un9f1313" transparent="1" />\n\t\t<widget name="key_green" position="773,799" zPosition="1" size="133,40" font="Regular;20" halign="center" valign="center" backgroundColor="un1f771f" transparent="1" />\n\t\t<widget name="lab1" position="205,70" size="560,50" font="Regular; 20" zPosition="2" transparent="0" halign="center" />\n\t\t<ePixmap alphatest="blend" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GREGUpdater/buttons/down.png" position="362,799" size="32,32" />\n\t\t<ePixmap alphatest="blend" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GREGUpdater/buttons/up.png" position="407,798" size="32,32" />\n\t\t<ePixmap alphatest="blend" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GREGUpdater/buttons/key_ok.png" position="478,796" size="57,36" />\n\t\t<ePixmap alphatest="blend" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GREGUpdater/buttons/key_exit.png" position="548,796" size="57,36" />\n\t\t<widget name="list" position="26,134" size="925,629" scrollbarMode="showOnDemand" transparent="1" />\n\t\t<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GREGUpdater/buttons/menu5.png" position="-2,0" size="973,857" zPosition="-5" transparent="1" />\n\t\t<ePixmap alphatest="blend" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GREGUpdater/buttons/update.png" position="844,17" size="89,41" />\n\t\t<widget source="Title" render="Label" position="5,12" size="939,50" font="Regular; 44" halign="left" foregroundColor="white" backgroundColor="transpBlack" transparent="1" />\n\t\t<applet type="onLayoutFinish">\n\t\t\tself["list"].instance.setItemHeight(25)\n\t\t</applet>\n\t</screen> '
 
    def __init__(self, session, args = 0):
        self.session = session
        Screen.__init__(self, session)
        self.skinName = ['GREGUpdater', 'ScriptRunner', 'VIXTAR.GZInstaller']
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'red': self.close,
         'green': self.action,
         'ok': self.action,
         'cancel': self.close}, -2)
        self['key_red'] = Button(_('Close'))
        self['key_green'] = Button(_('Run'))
        self['list'] = MenuList([])
        self['info'] = Label()
        self.slist = []
        title = 'GREG Updater'
        self.setTitle(title)
        for root, dirs, files in os.walk(path):
            for name in files:
                self.slist.append(name[:-3])

        self['list'].setList(self.slist)
        for f in glob.glob(path + '*.sh*'):
            os.system('chmod 755 ' + f)

    def action(self):
        sel = self['list'].getSelectionIndex()
        if sel is not None:
            self.shname = self.slist[sel] + '.sh'
            self.cmd = path + self.shname
            message = _('Are you ready to run the script ?')
            ybox = self.session.openWithCallback(self.Run, MessageBox, message, MessageBox.TYPE_YESNO)
            ybox.setTitle(_('Run Confirmation'))
        else:
            self.session.open(MessageBox, _('You have no script to run.'), MessageBox.TYPE_INFO, timeout=10)
        return

    def Run(self, answer):
        if answer is True:
            title = _(self.shname[:-3])
            self.session.open(Console, _(title), [self.cmd])


def main(session, **kwargs):
    session.open(GREGUpdater)


def Plugins(**kwargs):
    return [PluginDescriptor(name='GREG FHD Skins UPDATER', description='Instalacja Skins GREG FHD Aktualizacja ', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main, icon='custom-logo.png')]