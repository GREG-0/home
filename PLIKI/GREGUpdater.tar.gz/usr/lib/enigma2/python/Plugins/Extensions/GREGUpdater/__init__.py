# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/PiconUpdaer/__init__.py
pass